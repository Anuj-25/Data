package com.example.tycseb05ise1


import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        var orientation = this.resources.configuration.orientation
        val currOrientation = this.resources.configuration.orientation
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var b = findViewById<Button>(R.id.button)
        var tv = findViewById<TextView>(R.id.textView)
        var b1 = findViewById<Button>(R.id.button2)
        //var orientation = this.resources.configuration.orientation
        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            //reference https://stackoverflow.com/questions/3663665/how-can-i-get-the-current-screen-orientation
            tv.append("\nScreen is in Portrait Mode")
        } else {
            tv.append("\nScreen is in Landscape Mode")
        }
        //val currOrientation = this.resources.configuration.orientation
        b.setOnClickListener(View.OnClickListener{
            if (currOrientation == Configuration.ORIENTATION_PORTRAIT) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT)
            } else {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE)
            }
        })
        b1.setOnClickListener(View.OnClickListener{
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_USER);
            } else {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
            }
        })
    }
}